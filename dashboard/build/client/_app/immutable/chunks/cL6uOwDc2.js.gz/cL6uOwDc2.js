import{n as e}from"./DsF7k-Jl.js";import"./CFydX4Ia.js";import"./pJXbwm_7.js";import"./Cg4X8QED2.js";import"./BPYDJ6w12.js";import"./D2-0a4id2.js";import"./CWiCMZki2.js";import"./Lx4U1COv2.js";import"./4OoB9nwj.js";import"./Br3gREga.js";import"./BJS7CC7r.js";import"./Cp3m8-bB.js";import"./jxf6ubCd.js";import"./yp7BEYKo.js";import"./BPJqFGzM.js";import"./CP8i6059.js";import{r as t,t as n}from"./CE71TRqw.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};